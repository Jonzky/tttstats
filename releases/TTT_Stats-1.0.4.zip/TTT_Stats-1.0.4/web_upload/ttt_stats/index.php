<?php
/*------------------------\
|        TTT STATS        |
|	       Beta           |
|=========================|
|© 2013 SNGaming.org      |
|	All Rights Reserved   |
|=========================|
| 	Website printout      |
| 	   beta testing       |
| 	   by Handy_man       |
\------------------------*/				

include("./includes/header.php");
?>
							<div id="primary_content">
							<p>Welcome to Trouble In Terrorist Town Stats! Check our your player stats by following the Stats navigation.</p>
						</div>
				<?PHP include("./includes/footer.php");?>
