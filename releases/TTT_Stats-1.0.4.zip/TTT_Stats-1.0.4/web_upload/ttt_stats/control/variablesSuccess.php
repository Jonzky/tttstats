<?PHP
/*------------------------\
|        TTT STATS        |
|          Beta           |
|=========================|
|� 2013 SNGaming.org      |
|   All Rights Reserved   |
|=========================|
|   Website printout      |
|      beta testing       |
|      by Handy_man       |
\------------------------*/				
require("./includes/session_start.php");
include("./includes/header.php");
?>

<meta http-equiv="refresh" content="3;url=./index.php">

		<p class="center">Variables updated, please check the website to see if your changes have been introduced.</p>
		<p class="center">Click <a href="../index.php">here</a> if you'd prefer not to wait.</p>
<?PHP include("./includes/footer.php");?>