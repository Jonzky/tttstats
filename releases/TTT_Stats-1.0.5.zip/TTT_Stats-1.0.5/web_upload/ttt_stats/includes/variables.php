<?php 

$sb_enabled = false;

$sb_search_build = "http://bans.sngaming.org/index.php?p=banlist&searchText=";

$base_address = "http://www.sngaming.org";

$reports_enabled = true;

$servers_enabled = true;

$register_enabled = true;

$badge_enabled = true;

$badge_ref = "www.thehiddennation.com/ttt_stats";

$facebook_link = "sngaming2013";

$twitter_link = "skynet_gaming";

$youtube_link = "SkyNetNation";

$steam_link = "sky-netgaming";

$twitch_link = "skynetgaming";

$logo_path = "./static/images/ttt4_logo.png";

?>