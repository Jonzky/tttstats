<?php 
/*------------------------\
|        TTT STATS        |
|          Beta           |
|=========================|
|� 2013 SNGaming.org      |
|   All Rights Reserved   |
|=========================|
|   Website printout      |
|      beta testing       |
|      by Handy_man       |
\------------------------*/				

include("./includes/header.php");
?>
		<p class="center">Access to the Control panel section of the TTT Tracker is prohibited to <a href="login.php">login</a>!</p>
<?PHP include("./includes/footer.php");?>
