<?php
/*------------------------\
|        TTT STATS        |
|	       Beta           |
|=========================|
|© 2013 SNGaming.org      |
|	All Rights Reserved   |
|=========================|
| 	Website printout      |
| 	   beta testing       |
| 	   by Handy_man       |
\------------------------*/				
?>
				
				</div>
				<div class="clearfooter"></div>
				
				<div class="siteFooter">
				<div class="center">
					Please report issues with the TTT_STATS to the <a href="https://github.com/Jonzky/tttstats/issues?state=open">GitHub Issue Tracker</a>
				</div>
				</div>
		</body>
</html>