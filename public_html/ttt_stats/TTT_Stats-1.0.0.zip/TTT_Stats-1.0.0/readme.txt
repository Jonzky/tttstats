﻿** Readme **

Trouble in terrorist town stats

Copyright © 2013 - 2014 www.Thehiddennation.com

---------

Authors: Handy_man & Jonzky

Website: www.Thehiddennation.com

Install help: http://www.thehiddennation.com/ttt_stats/help.php

Having troubles?
FAQ: http://www.thehiddennation.com/ttt_stats/faq.php

Prerequisites
 * Webserver
   o PHP 5.0
   o MySQL 5.0
  * GameServer
   o MySQLOO database module
   o Garrysmod Trouble in terrorist town gamemode

